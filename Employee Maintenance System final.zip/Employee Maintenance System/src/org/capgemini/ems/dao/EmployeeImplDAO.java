package org.capgemini.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.capgemini.ems.bean.EmployeeBean;
import org.capgemini.ems.bean.GradeMasterBean;
import org.capgemini.ems.exception.EmployeeMaintenanceSystemException;
import org.capgemini.ems.util.DBConnection;

public class EmployeeImplDAO implements IEmployeeDAO {
	private static Logger myDAOLogger=Logger.getLogger(AdminDAOImpl.class);
	int employeeCount=0;
	static EmployeeBean employeeBean=new EmployeeBean();

	/*------------------------------EmployeeLogin---------------------------------------------*/
	@Override
	public boolean isValidEmployee(String name, String password)
			throws EmployeeMaintenanceSystemException {
		String sql="select * from user_master where username=? AND  userpassword=? And usertype=?";
		try {
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedstatement=connection.prepareStatement(sql);
			preparedstatement.setString(1, name);
			preparedstatement.setString(2, password);
			preparedstatement.setString(3, "Employee");

			ResultSet resultSet=preparedstatement.executeQuery();
			if(resultSet.next()){
				return true;

			}

		}catch(SQLException e){
			myDAOLogger.error(e.getMessage());

		} catch (EmployeeMaintenanceSystemException e) {
			myDAOLogger.error(e.getMessage());
			e.printStackTrace();
		}
		return false;
	}

	/*------------------------------Display details by using empID----------------------------*/
	@Override
	public List<EmployeeBean> getAllDetailsEmpID(String empid)
			throws EmployeeMaintenanceSystemException {
		List<EmployeeBean> employeeBeans=new ArrayList<EmployeeBean>();
		try {
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement
					("select * from Employee where emp_ID=?");
			preparedStatement.setString(1,empid);
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				EmployeeBean empl=new EmployeeBean();
				empl.setEmpId(resultSet.getString("emp_Id"));
				empl.setEmpFirstName(resultSet.getString("emp_First_Name"));
				empl.setEmpLastName(resultSet.getString("emp_Last_Name"));
				empl.setEmpDateOfBirth(resultSet.getDate("emp_Date_Of_Birth").toLocalDate());
				empl.setEmpDateOfJoining(resultSet.getDate("emp_Date_Of_Joining").toLocalDate());
				empl.setEmpDeptId(resultSet.getInt("emp_Dept_Id"));
				empl.setEmpGrade(resultSet.getString("emp_Grade"));
				empl.setEmpDesignation(resultSet.getString("emp_Designation"));
				empl.setEmpBasic(resultSet.getInt("emp_Basic"));
				empl.setEmpGender(resultSet.getString("emp_Gender"));
				empl.setEmpHomeAddress(resultSet.getString("emp_Home_Address"));
				empl.setEmpMaritalStatus(resultSet.getString("emp_Marital_Status"));
				empl.setEmpContactNum(resultSet.getString("emp_Contact_Num"));
				employeeBeans.add(empl);

			}
		} catch (SQLException e) {
			myDAOLogger.error(e.getMessage());
			//e.printStackTrace();
		}
		return employeeBeans;

	}

	/*------------------------------Display details by using empFirstName----------------------------*/
	@Override
	public List<EmployeeBean> getAllDetailsFirstName(String empFirstName)
			throws EmployeeMaintenanceSystemException {
		List<EmployeeBean> employeeBeans1=new ArrayList<EmployeeBean>();
		try {
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement
					("select * from Employee where EMP_FIRST_NAME=?");
			preparedStatement.setString(1,empFirstName);
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				EmployeeBean empl=new EmployeeBean();
				empl.setEmpId(resultSet.getString("emp_Id"));
				empl.setEmpFirstName(resultSet.getString("emp_First_Name"));
				empl.setEmpLastName(resultSet.getString("emp_Last_Name"));
				empl.setEmpDateOfBirth(resultSet.getDate("emp_Date_Of_Birth").toLocalDate());
				empl.setEmpDateOfJoining(resultSet.getDate("emp_Date_Of_Joining").toLocalDate());
				empl.setEmpDeptId(resultSet.getInt("emp_Dept_Id"));
				empl.setEmpGrade(resultSet.getString("emp_Grade"));
				empl.setEmpDesignation(resultSet.getString("emp_Designation"));
				empl.setEmpBasic(resultSet.getInt("emp_Basic"));
				empl.setEmpGender(resultSet.getString("emp_Gender"));
				empl.setEmpHomeAddress(resultSet.getString("emp_Home_Address"));
				empl.setEmpMaritalStatus(resultSet.getString("emp_Marital_Status"));
				empl.setEmpContactNum(resultSet.getString("emp_Contact_Num"));
				employeeBeans1.add(empl);

			}
		} catch (SQLException e) {
			myDAOLogger.error(e.getMessage());
			e.printStackTrace();
		}
		return employeeBeans1;
	}
	/*------------------------------Display details by using empLastName----------------------------*/
	@Override
	public List<EmployeeBean> getAllDetailsLastName(String empLastName)
			throws EmployeeMaintenanceSystemException {
		List<EmployeeBean> employeeBeans2=new ArrayList<EmployeeBean>();
		try {
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement
					("select * from Employee where EMP_LAST_NAME=?");
			preparedStatement.setString(1,empLastName);
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				EmployeeBean empl=new EmployeeBean();
				empl.setEmpId(resultSet.getString("emp_Id"));
				empl.setEmpFirstName(resultSet.getString("emp_First_Name"));
				empl.setEmpLastName(resultSet.getString("emp_Last_Name"));
				empl.setEmpDateOfBirth(resultSet.getDate("emp_Date_Of_Birth").toLocalDate());
				empl.setEmpDateOfJoining(resultSet.getDate("emp_Date_Of_Joining").toLocalDate());
				empl.setEmpDeptId(resultSet.getInt("emp_Dept_Id"));
				empl.setEmpGrade(resultSet.getString("emp_Grade"));
				empl.setEmpDesignation(resultSet.getString("emp_Designation"));
				empl.setEmpBasic(resultSet.getInt("emp_Basic"));
				empl.setEmpGender(resultSet.getString("emp_Gender"));
				empl.setEmpHomeAddress(resultSet.getString("emp_Home_Address"));
				empl.setEmpMaritalStatus(resultSet.getString("emp_Marital_Status"));
				empl.setEmpContactNum(resultSet.getString("emp_Contact_Num"));
				employeeBeans2.add(empl);

			}
		} catch (SQLException e) {
			myDAOLogger.error(e.getMessage());
			e.printStackTrace();
		}
		return employeeBeans2;
	}

	/*--------------------------Display details by using empDepartmentID----------------------------*/
	@Override
	public List<EmployeeBean> getAllDetailsDepartmentID(Integer empDeptId)
			throws EmployeeMaintenanceSystemException {
		List<EmployeeBean> employeeBeans3=new ArrayList<EmployeeBean>();
		try {
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement
					("select * from Employee where EMP_DEPT_ID=?");
			preparedStatement.setInt(1,empDeptId);
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				EmployeeBean empl=new EmployeeBean();
				empl.setEmpId(resultSet.getString("emp_Id"));
				empl.setEmpFirstName(resultSet.getString("emp_First_Name"));
				empl.setEmpLastName(resultSet.getString("emp_Last_Name"));
				empl.setEmpDateOfBirth(resultSet.getDate("emp_Date_Of_Birth").toLocalDate());
				empl.setEmpDateOfJoining(resultSet.getDate("emp_Date_Of_Joining").toLocalDate());
				empl.setEmpDeptId(resultSet.getInt("emp_Dept_Id"));
				empl.setEmpGrade(resultSet.getString("emp_Grade"));
				empl.setEmpDesignation(resultSet.getString("emp_Designation"));
				empl.setEmpBasic(resultSet.getInt("emp_Basic"));
				empl.setEmpGender(resultSet.getString("emp_Gender"));
				empl.setEmpHomeAddress(resultSet.getString("emp_Home_Address"));
				empl.setEmpMaritalStatus(resultSet.getString("emp_Marital_Status"));
				empl.setEmpContactNum(resultSet.getString("emp_Contact_Num"));
				employeeBeans3.add(empl);

			}
		} catch (SQLException e) {
			myDAOLogger.error(e.getMessage());
			e.printStackTrace();
		}
		return employeeBeans3;
	}

	/*------------------------------Display details by using empGrade----------------------------*/
	@Override
	public List<EmployeeBean> getAllDetailsGrade(String empgrade)
			throws EmployeeMaintenanceSystemException {
		List<EmployeeBean> employeeBeans4=new ArrayList<EmployeeBean>();
		try {
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement
					("select * from Employee where EMP_grade=?");
			preparedStatement.setString(1,empgrade);
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				EmployeeBean empl=new EmployeeBean();
				empl.setEmpId(resultSet.getString("emp_Id"));
				empl.setEmpFirstName(resultSet.getString("emp_First_Name"));
				empl.setEmpLastName(resultSet.getString("emp_Last_Name"));
				empl.setEmpDateOfBirth(resultSet.getDate("emp_Date_Of_Birth").toLocalDate());
				empl.setEmpDateOfJoining(resultSet.getDate("emp_Date_Of_Joining").toLocalDate());
				empl.setEmpDeptId(resultSet.getInt("emp_Dept_Id"));
				empl.setEmpGrade(resultSet.getString("emp_Grade"));
				empl.setEmpDesignation(resultSet.getString("emp_Designation"));
				empl.setEmpBasic(resultSet.getInt("emp_Basic"));
				empl.setEmpGender(resultSet.getString("emp_Gender"));
				empl.setEmpHomeAddress(resultSet.getString("emp_Home_Address"));
				empl.setEmpMaritalStatus(resultSet.getString("emp_Marital_Status"));
				empl.setEmpContactNum(resultSet.getString("emp_Contact_Num"));
				employeeBeans4.add(empl);

			}
		} catch (SQLException e) {
			myDAOLogger.error(e.getMessage());
			e.printStackTrace();
		}
		return employeeBeans4;
	}


	/*------------------------------Display details by using empmarital----------------------------*/
	@Override
	public List<EmployeeBean> getAllDetailsMaritalStatus(String empmarital)
			throws EmployeeMaintenanceSystemException {
		List<EmployeeBean> employeeBeans5=new ArrayList<EmployeeBean>();
		try {
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement
					("select * from Employee where EMP_MARITAL_STATUS=?");
			preparedStatement.setString(1,empmarital);
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				EmployeeBean empl=new EmployeeBean();
				empl.setEmpId(resultSet.getString("emp_Id"));
				empl.setEmpFirstName(resultSet.getString("emp_First_Name"));
				empl.setEmpLastName(resultSet.getString("emp_Last_Name"));
				empl.setEmpDateOfBirth(resultSet.getDate("emp_Date_Of_Birth").toLocalDate());
				empl.setEmpDateOfJoining(resultSet.getDate("emp_Date_Of_Joining").toLocalDate());
				empl.setEmpDeptId(resultSet.getInt("emp_Dept_Id"));
				empl.setEmpGrade(resultSet.getString("emp_Grade"));
				empl.setEmpDesignation(resultSet.getString("emp_Designation"));
				empl.setEmpBasic(resultSet.getInt("emp_Basic"));
				empl.setEmpGender(resultSet.getString("emp_Gender"));
				empl.setEmpHomeAddress(resultSet.getString("emp_Home_Address"));
				empl.setEmpMaritalStatus(resultSet.getString("emp_Marital_Status"));
				empl.setEmpContactNum(resultSet.getString("emp_Contact_Num"));
				employeeBeans5.add(empl);

			}
		} catch (SQLException e) {
			myDAOLogger.error(e.getMessage());
			e.printStackTrace();
		}
		return employeeBeans5;
	}

	@Override
	public List<GradeMasterBean> displayGradeStructure()
			throws EmployeeMaintenanceSystemException {
		String sql = "select * from Grade_Master";
		int count =0;
		try(
				Connection connection = DBConnection.getConnection();
				Statement smt = connection.createStatement();
				){
			ResultSet rs= smt.executeQuery(sql);
			List<GradeMasterBean> grade = new ArrayList<>();
			while(rs.next()){
				count++;
				GradeMasterBean grademaster = new GradeMasterBean();
				populate(rs,grademaster);
				grade.add(grademaster);
				
			}
			if(count>0){
				return grade;
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		
		
		return null;
		
	}

	private void populate(ResultSet rs, GradeMasterBean grademaster) throws SQLException {
		grademaster.setGradeCode(rs.getString(1));
		grademaster.setDescription(rs.getString(2));
		grademaster.setMinSalary(rs.getDouble(3));
		grademaster.setMaxSalary(rs.getDouble(4));
		
		
	}

	}


