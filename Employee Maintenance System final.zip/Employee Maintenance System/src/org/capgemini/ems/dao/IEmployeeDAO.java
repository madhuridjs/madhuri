package org.capgemini.ems.dao;

import java.util.List;

import org.capgemini.ems.bean.EmployeeBean;
import org.capgemini.ems.bean.GradeMasterBean;
import org.capgemini.ems.exception.EmployeeMaintenanceSystemException;

public interface IEmployeeDAO {
	
	public boolean isValidEmployee(String name, String password) throws EmployeeMaintenanceSystemException;

	public List<EmployeeBean> getAllDetailsEmpID(String empid) throws EmployeeMaintenanceSystemException;

	public List<EmployeeBean> getAllDetailsFirstName(String empFirstName) throws EmployeeMaintenanceSystemException;

	public List<EmployeeBean> getAllDetailsLastName(String empLastName) throws EmployeeMaintenanceSystemException;

	public List<EmployeeBean> getAllDetailsDepartmentID(Integer empDeptId) throws EmployeeMaintenanceSystemException;

	public List<EmployeeBean> getAllDetailsGrade(String empgrade) throws EmployeeMaintenanceSystemException;

	public List<EmployeeBean> getAllDetailsMaritalStatus(String empmarital) throws EmployeeMaintenanceSystemException;
	
	public List<GradeMasterBean> displayGradeStructure() throws EmployeeMaintenanceSystemException;  

	
}
