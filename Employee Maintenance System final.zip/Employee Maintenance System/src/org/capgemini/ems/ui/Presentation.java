package org.capgemini.ems.ui;


import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.capgemini.ems.bean.EmployeeBean;
import org.capgemini.ems.bean.UserMasterBean;
import org.capgemini.ems.dao.AdminDAOImpl;
import org.capgemini.ems.dao.IAdminDAO;
import org.capgemini.ems.exception.EmployeeMaintenanceSystemException;
import org.capgemini.ems.service.AdminServiceImpl;
import org.capgemini.ems.service.EmployeeService;
import org.capgemini.ems.service.IAdminService;
import org.capgemini.ems.service.IEmployeeService;
import org.capgemini.ems.view.UIAdmin;
import org.capgemini.ems.view.UIEmployee;



public class Presentation {

	private static Scanner scanner = new Scanner(System.in);
	UserMasterBean userMasterBean=new UserMasterBean();
	static EmployeeBean employeeBean=new EmployeeBean();
	static IAdminService adminservice =new AdminServiceImpl();
	static IAdminDAO adminDAO=new AdminDAOImpl();
	static IEmployeeService employeeservice=new EmployeeService();
	private static UIAdmin uiAdmin=new UIAdmin();
	private static UIEmployee uiEmployee=new UIEmployee();
	private static Logger myUILogger=Logger.getLogger(Presentation.class);
	public static void main(String[] args) throws EmployeeMaintenanceSystemException {
		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println(" Employee Maintenance System ");
			System.out.println("_______________________________\n");

			System.out.println("1. Admin Login");
			System.out.println("2. Employee Login");
			System.out.println("3. Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			try {
				int option = scanner.nextInt();

				switch (option) {
 

				case 1:	System.out.println("Enter User Name:");
				String aName=scanner.next();
				System.out.println("Enter Password");
				String aPassword=scanner.next();
				if(adminservice.isValidAdmin(aName,aPassword)){
					System.out.println("Login Successful :) ");
					System.out.println("1.Add Employee");
					System.out.println("2.Modify Employee");
					System.out.println("3.Display All Employees");
					System.out.println("4.LogOut");
					int option1 = scanner.nextInt();
					uiAdmin.adminModule(option1);


				}else System.out.println("Enter valid username and password");


				break;
				case 2:System.out.println("Enter your name: ");
				scanner.nextLine();
				String name=scanner.nextLine();
				//System.out.println(name);
				System.out.println("Enter your password: ");
				String password=scanner.nextLine();	
				if(employeeservice.isValidEmployee(name, password)){
					System.out.println("Login Successful :) ");
					System.out.println("1.Search for the Employee");
					System.out.println("2.LogOut");			
					int option2 = scanner.nextInt();
					uiEmployee.employeeModule(option2);
				}else{
					System.out.println("Enter valid username and password");
				}
				break;
				case 3:

					System.out.print("Exit Employee Maintenance System");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-3]");
				}// end of switch
			}//end of try

			catch (InputMismatchException e) {
				myUILogger.info("Input mismatch Error");
				scanner.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}

		}// end of while

	}


}


