package org.capgemini.ems.view;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;



import org.capgemini.ems.bean.EmployeeBean;
import org.capgemini.ems.bean.UserMasterBean;
import org.capgemini.ems.dao.AdminDAOImpl;
import org.capgemini.ems.dao.IAdminDAO;
import org.capgemini.ems.exception.EmployeeMaintenanceSystemException;
import org.capgemini.ems.service.AdminServiceImpl;
import org.capgemini.ems.service.EmployeeService;
import org.capgemini.ems.service.IAdminService;
import org.capgemini.ems.service.IEmployeeService;

public class UIEmployee {
	private static Scanner scanner = new Scanner(System.in);
	UserMasterBean userMasterBean=new UserMasterBean();
	static EmployeeBean employeeBean=new EmployeeBean();
	static IAdminService adminservice =new AdminServiceImpl();
	static IEmployeeService employeeservice=new EmployeeService();
	static IAdminDAO adminDAO=new AdminDAOImpl();
	public void employeeModule(int option2) throws EmployeeMaintenanceSystemException {

		switch (option2) {

		case 1:System.out.println("Enter the option to Search: \n 1.Employee Id \n 2.FirstName \n 3.LastName \n 4.DepartmentID \n 5.grade \n 6.maritalstatus ");
		int options=scanner.nextInt();
		scanner.nextLine();
		{
			switch(options){
			case 1:System.out.println("Enter employeeID");
			String empid=scanner.nextLine();
			List<EmployeeBean> employeeBeans= employeeservice.getAllDetailsEmpID(empid);
			Iterator<EmployeeBean> iterator=employeeBeans.iterator();
			while(iterator.hasNext()){
				System.out.println(iterator.next());
			}
			break;
			case 2:System.out.println("Enter FirstName");
			String empFirstName=scanner.nextLine();
			List<EmployeeBean> employeeBeans1= employeeservice.getAllDetailsFirstName(empFirstName);
			Iterator<EmployeeBean> iterator1=employeeBeans1.iterator();
			while(iterator1.hasNext()){
				System.out.println(iterator1.next());
			}
			break;
			case 3:System.out.println("Enter LastName");
			String empLastName=scanner.nextLine();
			List<EmployeeBean> employeeBeans2= employeeservice.getAllDetailsLastName(empLastName);
			Iterator<EmployeeBean> iterator2=employeeBeans2.iterator();
			while(iterator2.hasNext()){
				System.out.println(iterator2.next());
			}
			break;
			case 4:System.out.println("Enter Department");
			Integer empDeptId=scanner.nextInt();
			List<EmployeeBean> employeeBeans3= employeeservice.getAllDetailsDepartmentID(empDeptId);
			Iterator<EmployeeBean> iterator3=employeeBeans3.iterator();
			while(iterator3.hasNext()){
				System.out.println(iterator3.next());
			}
			break;
			case 5:System.out.println("Enter grade");
			String empgrade=scanner.nextLine();
			List<EmployeeBean> employeeBeans4= employeeservice.getAllDetailsGrade(empgrade);
			Iterator<EmployeeBean> iterator4=employeeBeans4.iterator();
			while(iterator4.hasNext()){
				System.out.println(iterator4.next());
			}
			break;
			case 6:System.out.println("Enter marital status");
			String empmarital=scanner.nextLine();
			List<EmployeeBean> employeeBeans5= employeeservice.getAllDetailsMaritalStatus(empmarital);
			Iterator<EmployeeBean> iterator5=employeeBeans5.iterator();
			while(iterator5.hasNext()){
				System.out.println(iterator5.next());
			}
			break;
			}
		}
		break;
		case 2:
			System.out.print("User Exited from Employee Maintenance System");
			System.exit(0);
			break;
		default:
			System.out.println("Enter a valid option[1-4]");
		}

	}

}
