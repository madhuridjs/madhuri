package org.capgemini.ems.bean;

public class GradeMasterBean {
	private  String GradeCode;
	private String Description;  
	private Double MinSalary;
	private Double MaxSalary;

	public GradeMasterBean(){
		
	}

	public GradeMasterBean(String gradeCode, String description,
			Double minSalary, Double maxSalary) {
		super();
		GradeCode = gradeCode;
		Description = description;
		MinSalary = minSalary;
		MaxSalary = maxSalary;
	}

	public String getGradeCode() {
		return GradeCode;
	}

	public void setGradeCode(String gradeCode) {
		GradeCode = gradeCode;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public Double getMinSalary() {
		return MinSalary;
	}

	public void setMinSalary(Double minSalary) {
		MinSalary = minSalary;
	}

	public Double getMaxSalary() {
		return MaxSalary;
	}

	public void setMaxSalary(Double maxSalary) {
		MaxSalary = maxSalary;
	}

	@Override
	public String toString() {
		return "GradeMasterBean [GradeCode=" + GradeCode + ", Description="
				+ Description + ", MinSalary=" + MinSalary + ", MaxSalary="
				+ MaxSalary + "]";
	}
	
	
}
