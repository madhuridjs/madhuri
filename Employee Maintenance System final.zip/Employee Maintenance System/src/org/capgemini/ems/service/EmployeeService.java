package org.capgemini.ems.service;

import java.util.List;

import org.capgemini.ems.bean.EmployeeBean;
import org.capgemini.ems.bean.GradeMasterBean;
import org.capgemini.ems.bean.UserMasterBean;
import org.capgemini.ems.dao.EmployeeImplDAO;
import org.capgemini.ems.dao.IEmployeeDAO;
import org.capgemini.ems.exception.EmployeeMaintenanceSystemException;

public class EmployeeService implements IEmployeeService {
IEmployeeDAO employeedao=new EmployeeImplDAO();
UserMasterBean userMasterBean=new UserMasterBean();
	@Override
	public boolean isValidEmployee(String name, String password)
			throws EmployeeMaintenanceSystemException {
		return employeedao.isValidEmployee(name, password);
	
	}

	@Override
	public List<EmployeeBean> getAllDetailsEmpID(String empid)
			throws EmployeeMaintenanceSystemException {
		return employeedao.getAllDetailsEmpID(empid);
			}

	@Override
	public List<EmployeeBean> getAllDetailsFirstName(String empFirstName)
			throws EmployeeMaintenanceSystemException {
		return employeedao.getAllDetailsFirstName(empFirstName);
	}

	@Override
	public List<EmployeeBean> getAllDetailsLastName(String empLastName)
			throws EmployeeMaintenanceSystemException {
		return employeedao.getAllDetailsLastName(empLastName);
			}

	@Override
	public List<EmployeeBean> getAllDetailsDepartmentID(Integer empDeptId)
			throws EmployeeMaintenanceSystemException {
		return employeedao.getAllDetailsDepartmentID(empDeptId);
	}

	@Override
	public List<EmployeeBean> getAllDetailsGrade(String empgrade)
			throws EmployeeMaintenanceSystemException {
		return employeedao.getAllDetailsGrade(empgrade);
	}

	@Override
	public List<EmployeeBean> getAllDetailsMaritalStatus(String empmarital)
			throws EmployeeMaintenanceSystemException {
		return employeedao.getAllDetailsMaritalStatus(empmarital);

			}

	@Override
	public List<GradeMasterBean> displayGradeStructure()
			throws EmployeeMaintenanceSystemException {
		
		return employeedao.displayGradeStructure();
	}

	

}
