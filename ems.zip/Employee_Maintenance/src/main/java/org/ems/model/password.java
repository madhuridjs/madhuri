package org.empMaintanence.model;

public class password {

	private String nickName;
	
	private String school;
	
	private String fatherProfession;
	
	private String hobby;

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public String getSchool() {
		return school;
	}

	public void setSchool(String school) {
		this.school = school;
	}

	public String getFatherProfession() {
		return fatherProfession;
	}

	public void setFatherProfession(String fatherProfession) {
		this.fatherProfession = fatherProfession;
	}

	public String getHobby() {
		return hobby;
	}

	public void setHobby(String hobby) {
		this.hobby = hobby;
	}

	@Override
	public String toString() {
		return "password [nickName=" + nickName + ", school=" + school + ", fatherProfession=" + fatherProfession
				+ ", hobby=" + hobby + "]";
	}

	public password(String nickName, String school, String fatherProfession, String hobby) {
		super();
		this.nickName = nickName;
		this.school = school;
		this.fatherProfession = fatherProfession;
		this.hobby = hobby;
	}

	public password() {
		super();
	}
	
	
	

}
