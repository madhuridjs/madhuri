package org.capgemini.ems.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.capgemini.ems.bean.UserMasterBean;
import org.capgemini.ems.service.ILoginService;
import org.capgemini.ems.service.LoginServiceImpl;

public class Presentation {
private static ILoginService loginservice=new LoginServiceImpl();
	private static Scanner scanner = new Scanner(System.in);
	UserMasterBean userMasterBean=new UserMasterBean();
	public static void main(String[] args) {
		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println(" Employee Maintenance System ");
			System.out.println("_______________________________\n");

			System.out.println("1. Admin Login");
			System.out.println("2. Employee Login");
			System.out.println("3. Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			try {
				int option = scanner.nextInt();

				switch (option) {


				case 1:	
					
					
				case 2:System.out.println("Enter User_id");
				String username=scanner.next();
				System.out.println("Enter Password");
				String UserPassword=scanner.next();
				
				ILoginService loginService = new LoginServiceImpl();
				
					
					
				case 3:

					System.out.print("Exit Employee Maintenance System");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-3]");
				}// end of switch
			}//end of try

			catch (InputMismatchException e) {
				scanner.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}

		}// end of while

	}
}




