package org.capgemini.ems.dao;

import org.capgemini.ems.bean.UserMasterBean;

import org.capgemini.ems.exception.EmployeeMaintenanceSystemException;

public interface ILoginDAO {
	public boolean isValidLogin(String username,String UserPassword) throws EmployeeMaintenanceSystemException;

}
