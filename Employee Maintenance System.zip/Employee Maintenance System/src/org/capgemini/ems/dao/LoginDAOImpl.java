package org.capgemini.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.capgemini.ems.bean.UserMasterBean;
import org.capgemini.ems.exception.EmployeeMaintenanceSystemException;
import org.capgemini.ems.util.DBConnection;



public class LoginDAOImpl implements ILoginDAO{

	@Override
	public boolean isValidLogin(String username, String UserPassword) throws EmployeeMaintenanceSystemException {
		try {
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedstatement=connection.prepareStatement
					("select * from Usermaster where username=? AND  Userpassword=?");
			preparedstatement.setString(1, "username");
			preparedstatement.setString(2, "password");
		
			ResultSet resultSet=preparedstatement.executeQuery();
			while(resultSet.next()) {
				String user=resultSet.getString("username");
				String password=resultSet.getString("UserPassword");
				
				if(username.equals(user) && UserPassword.equals(password)){
					System.out.println("success");
					return true;
				}
				
				return false;
			}
			
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new EmployeeMaintenanceSystemException  ("Technical Error. Contact Logs");

		}
		return false;
		
	}
		
	}


