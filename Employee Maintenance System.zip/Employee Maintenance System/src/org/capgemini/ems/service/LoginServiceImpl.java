package org.capgemini.ems.service;

import org.capgemini.ems.bean.UserMasterBean;
import org.capgemini.ems.dao.ILoginDAO;
import org.capgemini.ems.dao.LoginDAOImpl;
import org.capgemini.ems.exception.EmployeeMaintenanceSystemException;

public class LoginServiceImpl implements ILoginService{
ILoginDAO logindao=new LoginDAOImpl();
	@Override
	public boolean isValidLogin(String username, String UserPassword) throws EmployeeMaintenanceSystemException {
		logindao.isValidLogin(username, UserPassword);
				return false;
	}

}
