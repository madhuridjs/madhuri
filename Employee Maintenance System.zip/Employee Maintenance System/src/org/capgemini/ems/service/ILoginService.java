package org.capgemini.ems.service;

import org.capgemini.ems.bean.UserMasterBean;
import org.capgemini.ems.exception.EmployeeMaintenanceSystemException;

public interface ILoginService {
	public boolean isValidLogin(String username,String UserPassword) throws EmployeeMaintenanceSystemException;
}
